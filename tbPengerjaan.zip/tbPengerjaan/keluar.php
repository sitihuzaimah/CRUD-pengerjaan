<?php
session_start();
session_destroy();
unset($_SESSION['id']);
header('location:/tbPengerjaan/masuk.php');
exit();
?>