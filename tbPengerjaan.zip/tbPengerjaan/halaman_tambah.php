<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah</title>
    <style>
        body {
            width: 800px; 
            margin: Auto; 
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 90vh;
            background-color: #060a1f;
        }
        h2 {
            text-align: center;
            text-transform: uppercase;
            text-underline-position: under;
            text-decoration: underline black;
        }
        button {
            padding: 10px;
            font-weight: bold;
            color: white;
            background-color: #4caf50;
            border: none;
            font-size: 16px;
            cursor: pointer;
            display: block;
            margin-top: 20px;
            float: right;
        }
        label{
            font-weight: bold;
            display: block;
            font-size: 20px;
            margin-bottom: 10px;
        }
        input, select{
            width: 100%;
            padding: 10px;
            border: 1px solid gray;
            border-radius: 5px;
            box-sizing: border-box;
        }
        select option {
            padding: 10px;
            font-size: 20px;
        }
        div{
            border: 1px solid black;
            padding: 20px;
            width: 90%;
            background-color: white;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div>
        <h2> Form Upload File Lainnya</h2>
        <form action="ScriptFileUpload.php" method="post" enctype="multipart/form-data">
            <?php 
                include 'koneksi.php';
            ?>
            <label>ID : </label>
            <input type="text" name="kode" required="required" value="<?php echo $kode = ambilKode() ?>" readonly>
            <label>Nomor Order : </label>
            <input type="text" name="no_order" placeholder="Masukkan Nomor Order">
            <label>ID Admin : </label>
            <input type="text" name="admin_id" placeholder="Masukkan ID Admin">
            <label>Status Pembayaran : </label>
            <select name="bayar">
                <option value="Sudah Bayar">Sudah Bayar</option>
                <option value="Belum Bayar">Belum Bayar</option>
            </select>
            <!-- <label>Upload File : </label>
            <input type="file" name="berkas" accept="application/pdf"> -->
            <button type="submit">Upload File</button> 
        </form>
    </div>
</body>
</html>