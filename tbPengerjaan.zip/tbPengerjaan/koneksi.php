<?Php 

Function KoneksiDB() {
    
    $host = "localhost";
    $username = "root";
    $password = "";
    $Db = "dbPelayanan";

    $Conn = Mysqli_connect($host, $username, $password, $Db);
    
    If(!$Conn) {
        Die("Koneksi Database Gagal : " .Mysqli_connect_error());
    } else {
        return $Conn;
    }
}

function insertData($data){
    $query = "INSERT INTO pengerjaan VALUES ('".$data['id']."','".$data['no_order']."','".$data['admin_id']."','".$data['bayar']."')";

    $result = mysqli_query(KoneksiDB(),$query);

    if (!$result){
        return 0;
    } else {
        return 1;
    }
}



function selectAllData(){
    $query = "SELECT a.NoOrder,a.email,a.nm_user, a.no_hp, a.jasa, a.hari, a.deadline, a.berkas, b.id, b.admin_id, b.bayar FROM user a LEFT JOIN pengerjaan b ON a.NoOrder=b.no_order";
    $data = mysqli_query(KoneksiDB(),$query);
    return $data;
    //$query = "SELECT * FROM pengerjaan";
    //$result = mysqli_query(KoneksiDB(), $query);
    //return $result;
}

function ambilKode(){
    $query = "SELECT MAX(RIGHT(id, 3)) as maxKode FROM pengerjaan";
                $hasil = mysqli_query(KoneksiDB(), $query);
                $data = mysqli_fetch_assoc($hasil);
                $maxKode = $data['maxKode'];

                // Mengambil 3 digit angka terakhir dari kode terbesar dan menambahkan 1
                if ($maxKode == null) {
                    $noUrut = 1;
                } else {
                    $noUrut = intval($maxKode) + 1;
                }

                // Menghasilkan kode baru dengan format TLS-XXX (XXX adalah 3 digit angka terakhir)
                $kode = "ID-" . sprintf("%03s", $noUrut);

                return $kode;
}
 ?>