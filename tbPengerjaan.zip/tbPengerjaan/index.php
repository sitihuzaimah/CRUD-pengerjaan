<!DOCTYPE Html>
<Html>
<Head>
    <Title>Upload Dan Download File PDF Dengan PHP Dan MySQL</Title>
    <style>
        body {
            width: 1200px; 
            margin: Auto; 
            padding: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 90vh;
            background-color: #060a1f;
        }
        h2 {
            text-align: center;
            text-transform: uppercase;
            text-underline-position: under;
            text-decoration: underline black;
        }
        button {
            padding: 10px;
            font-weight: bold;
            color: white;
            background-color: #4caf50;
            border: none;
            font-size: 16px;
            cursor: pointer;
        }
        table{
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        table thead{
            background-color: gray;
            border: 1px solid black;
            font-size: 16px;
            height: 50px;
            color: white;
        }
        table td{
            text-align: center;
            padding: 10px;
        }
        label{
            font-weight: bold;
            color: white;
            background-color: red;
            padding: 5px 10px;
            border-radius: 5px;
        }
        a{
            text-decoration: none;
            font-weight: bold;
            background-color: #4caf50;
            padding: 5px 10px;
            color: white;
        }
        a:hover{
            color: black;
        }
        div{
            border: 1px solid black;
            padding: 20px;
            width: 100%;
            background-color: white;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <div>
        <h2>Upload dan Download File</h2>
        <button onclick="document.location='halaman_tambah.php'">Tambah Data</button>
        <button onclick="document.location='keluar.php'">Keluar</button>
        
        <table border="1">
        <Thead>
            <Tr>
                <Th Style="Width: 30px">Nomor Order</Th>
                <Th Style="Width: 100px">Email</Th>
                <Th>Nama</Th>
                <Th Style="Width: 100px">Nomor Hp</Th>
                <Th Style="Width: 100px">Jasa</Th>
                <Th Style="Width: 100px">Lama Pengerjaan</Th>
                <Th Style="Width: 100px">Deadline</Th>
                <Th Style="Width: 100px">ID</Th>
                <Th Style="Width: 100px">ID Admin</Th>
                <Th Style="Width: 100px">Status Pembayaran</Th>
                <Th Style="Width: 100px">Berkas</Th>

                <!-- <Th Style="Width: 30px">ID</Th>
                <Th Style="Width: 100px">Nomor Order</Th>
                <Th>ID Admin</Th>
                <Th Style="Width: 100px">Status Pembayaran</Th>
                <Th Style="Width: 100px">File</Th> -->
            </Tr>
        </Thead>

        <tbody>
            <?php
                include 'koneksi.php';

                include 'session.php';
                $username = $_SESSION['usn'];
                $userID = $_SESSION['id'];

                $query = "SELECT MAX(RIGHT(id, 3)) as maxKode FROM pengerjaan";
                $hasil = mysqli_query(KoneksiDB(), $query);
                $data = mysqli_fetch_assoc($hasil);
                $maxKode = $data['maxKode'];

                // Mengambil 3 digit angka terakhir dari kode terbesar dan menambahkan 1
                if ($maxKode == null) {
                    $noUrut = 1;
                } else {
                    $noUrut = intval($maxKode) + 1;
                }

                // Menghasilkan kode baru dengan format TLS-XXX (XXX adalah 3 digit angka terakhir)
                $kode = "ID-" . sprintf("%03s", $noUrut);
                
            
                $data = selectAllData();
                if (($data->current_field==0)){
            ?>
            <tr>
                <td colspan="11" style="text-align: center; font-weight: bold; font-size: 12px; padding: 5px;">Data Tidak Tersedia</td>
            </tr>
            <?php } else {
                while ($result = mysqli_fetch_assoc($data)){
            ?>
            <tr>
                <td><?= $result['NoOrder'] ?></td>
                <td><?= $result['email'] ?></td>
                <td><?= $result['nm_user'] ?></td>
                <td><?= $result['no_hp'] ?></td>
                <td><?= $result['jasa'] ?></td>
                <td><?= $result['hari'] ?></td>
                <td><?= $result['deadline'] ?></td>
                <td><?= $result['id'] ?></td>
                <td><?= $result['admin_id'] ?></td>
                <td><?= $result['bayar'] ?></td>
                <td><a href="berkas/<?php echo $result['berkas']; ?>">Download</a></td>


            </tr>
            <?php }} ?>

        </tbody>
        </table>
    </div>
</body>
</html>