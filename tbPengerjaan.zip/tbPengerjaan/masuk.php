<?php
include 'koneksi.php';
session_start();

if(isset($_SESSION['id'])){
    header('location:index.php');
}

if(isset($_POST['log'])){
    $user = $_POST['usn'];
    $pass =  $_POST['pass'];

    $query = "SELECT * FROM admin where usn = '$user' and pass = '$pass'";
    $result = mysqli_query(KoneksiDB(),$query);

    if($result-> num_rows > 0){
        while($row= $result->fetch_assoc()){
            $_SESSION['id'] = $row['id'];
            $_SESSION['usn'] = $row['usn']; 
        }
?>
        <script> alert('Welcome <?php echo $_SESSION['usn']?>'); </script>
        <script>window.location='masuk.php';</script>
<?php
    } else {
        echo "<center><p style=color:red;>Invalid username or password</p></center>";
    }
    $Conn->close();
}
?>

<form action="masuk.php" method="POST">
    <html>
    <center><h3>Login Here :</h3></center>
    <table align="center" bgcolor="tan" width="200">
        <tr>
            <td>
                Username:
            </td>
            <td>
                <input type="text" name="usn" required>
            </td>
        </tr>
        <tr>
            <td>
                Password:
            </td>
            <td>
                <input type="password" name="pass" required>
            </td>
        </tr>
        <tr>
            <td align="center" colspan="2" bgcolor="teal">
                <input type="submit" value="login" name="log">
            </td>
        </tr>
    </table>
    </html>
</form>
