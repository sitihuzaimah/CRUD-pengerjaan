<?php
    require ('koneksi.php');

    $kode = $_POST['kode'];
    $nomor = $_POST['no_order'];
    $admin = $_POST['admin_id'];
    $bayar = $_POST['bayar'];
    // $file = $data['file'];
    // $fileName = $data['berkas'];
    // $nmFile = $_FILES['berkas']['name'];
    // $file_tmp = $_FILES['berkas']['tmp_name'];

    // $dirUpload = 'file/';
    // $linkBerkas = $dirUpload.$nmFile;

    // $terupload = move_uploaded_file($file_tmp, $linkBerkas);
    $dataArr = array (
        'id' => $kode,
        'no_order' => $nomor,
        'admin_id' => $admin,
        'bayar' => $bayar,
        //'berkas' => $linkBerkas,
    );

    if ( (insertData($dataArr) == 1)){
        echo "Upload berhasil";
        header("Location: index.php", true, 301);
    } else {
        echo "Upload Gagal";
        header("Location: halaman_tambah.php", true, 301);
    }

?>